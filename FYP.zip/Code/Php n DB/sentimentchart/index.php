<?php
require_once('db.php');
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <title>Sentiment Analysis Graph</title>
  </head>
  <body>
    <h1>Sentiment Analysis Graph</h1>
    <p><img src="sentiment.php" /></p>
    <p><img src="total_sentiment.php" /></p>
	
		<p><a href="view_sentiment.php">View Total Sentiment</a></p>



  </body>
</html>
