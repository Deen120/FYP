import sys
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QDialog, QApplication, QStackedWidget, QMessageBox
from process import pr
import pickle
import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import mysql.connector


class WelcomeScreen(QDialog):
    def __init__(self):
        super(WelcomeScreen, self).__init__()

        loadUi("main.ui", self)

        self.pred.clicked.connect(self.predict)
        self.reset.clicked.connect(self.clearAll)
    def clearAll(self):
        try:
            self.logreglbl.setText("")
            self.lbl_pred.setText("")
            self.lbl_final.setText("")
            self.data.setText("")
            self.word = " "

        except:
            pass
    
        
         
        

    def predict(self):
        try:
           
            
            words = self.data.text()
            print(words)
            svm = pickle.load(open('svm.pkl', 'rb'))
            nb = pickle.load(open('NB.pkl', 'rb'))
            logreg = pickle.load(open('logreg.pkl', 'rb'))
            data = {'Review': [words]}
            df = pd.DataFrame(data)
            word = pr(df)
            pre_svm = svm.predict(word)
            pre_logreg = logreg.predict(word)
            pre_nb = nb.predict(word)
            pre_svm = str(pre_svm).replace('[', '').replace(']', '')
            pre_nb = str(pre_nb).replace('[', '').replace(']', '')
            pre_logreg = str(pre_logreg).replace('[', '').replace(']', '')
            self.lbl_pred.setText("Result SVM: {0}, NB: {1}, logreg: {2}".format(pre_svm,pre_nb,pre_logreg))
            print("Result SVM: {0}, NB: {1}, logreg: {2}".format(pre_svm,pre_nb,pre_logreg))
            
            totalsentiment = (int(pre_svm)+int(pre_nb)+int(pre_logreg))

            if (totalsentiment > 1) :
              consensus = 1        
            else:
              consensus=0        
            if (consensus>0):
                consensus_text = "POSITIVE"
            else:
                consensus_text = "NEGATIVE"
            self.lbl_final.setText("Final Sentiment {0}".format(consensus_text))
                   
            print("Final Sentiment {0}".format(consensus_text))
            
            mydb = mysql.connector.connect(
              host="localhost",
              user="root",
              password="",
              database="sentimentdb"
             )
            mycursor = mydb.cursor()
            #sql = "INSERT INTO sentiment (name, address) VALUES (%s, %s)"
            sql1= "INSERT INTO sentiment (comment, svm, logreg, naivebayes, consensus) VALUES (%s, %s, %s, %s, %s);"
            val = (str(words), int(pre_svm), int(pre_nb), int(pre_logreg), consensus)
            mycursor.execute(sql1, val)
            
            mydb.commit()
            
            print(mycursor.rowcount, "record inserted.")
            prompt = QMessageBox.question(
                self, "Message",
                f"1 record inserted",
                QMessageBox.Ok)
            if prompt == QMessageBox.Ok:
                pass 
            
           
            
            
            # # if pre_nb == 0:
            # #     print(f"NB : NEGATIVE WORD")
            # #     self.nblbl.setText(f"NB : NEGATIVE WORD")
            # else:
            #     print(f"NB : POSITIVE WORD")
            #     self.nblbl.setText(f"NB : POSITIVE WORD")

        except:
            print("error")
            prompt = QMessageBox.question(
                self, "Message",
                f"Error in predict",
                QMessageBox.Ok)
            if prompt == QMessageBox.Ok:
                pass 



#main
app = QApplication(sys.argv)
welcome=WelcomeScreen()
widget = QStackedWidget()
widget.addWidget(welcome) 
widget.setFixedHeight(366)
widget.setFixedWidth(665)
widget.setWindowTitle("SENTIMENT ANALYSIS BASED ON KDRAMA REVIEWS")
widget.show()
 
try:
    sys.exit(app.exec())
except:
    print("Exiting")