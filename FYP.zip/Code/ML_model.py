import pickle
from sklearn.metrics import confusion_matrix, classification_report

def dataset():
    from tkinter import Tk
    from tkinter.filedialog import askopenfilename
    Tk().withdraw()  # hide Tk windows from open
    filename = askopenfilename()

    import pandas as pd
    dataset = pd.read_csv(filename)
    return dataset


train = dataset()
test = dataset()
# print(train.count())
# print(test.count())
# print(test.head())

def word_processing(train, test):
    
    import pandas as pd
    import string  # used for preprocessing
    import re  # used for preprocessing
    import nltk
    from nltk.tokenize import word_tokenize
    from sklearn.metrics import f1_score
    from nltk.corpus import stopwords  # used for preprocessing
    from nltk.stem import WordNetLemmatizer  # used for preprocessing
    from sklearn.feature_extraction.text import TfidfVectorizer
    nltk.download('stopwords')
    nltk.download('wordnet')
    nltk.download('punkt')

    # make all text lowercase
    def text_lowercase(text):
        return text.lower()

    # remove numbers
    #def remove_numbers(text):
        #result = re.sub(r'\d+', '', text)
        #return result

    PUNCT_TO_REMOVE = string.punctuation

    def remove_punctuation(text):
        text = "".join(u for u in text if u not in ("?", ".", ";", ":", "!", '"', ",", "-", ">", "/", ";", "%"))
        return text.translate(str.maketrans('', '', PUNCT_TO_REMOVE))

    # tokenize
    def tokenize(text):
        text = word_tokenize(text)
        return text

    # remove stopwords
    stop_words = set(stopwords.words('english'))

    def remove_stopwords(text):
        text = [i for i in text if not i in stop_words]
        return text

    # lemmatize
    lemmatizer = WordNetLemmatizer()

    def lemmatize(text):
        text = [lemmatizer.lemmatize(token) for token in text]
        return text

    def preprocessing(text):
        text = text_lowercase(text)
        #text = remove_numbers(text)
        text = remove_punctuation(text)
        text = tokenize(text)
        text = remove_stopwords(text)
        text = lemmatize(text)
        text = ' '.join(text)
        return text


    pp_text_train = []  # our preprocessed text column
    for text_data in train['Review ']:
        pp_text_data = preprocessing(text_data)
        pp_text_train.append(pp_text_data)
    train['New_Review'] = pp_text_train  # add the preprocessed text as a column

    pp_text_test = []  # our preprocessed text column
    for text_data in test['Review ']:
        pp_text_data = preprocessing(text_data)
        pp_text_test.append(pp_text_data)
    test['Test_Review'] = pp_text_test  # add the preprocessed text as a column

    # combine train and test into corpus of text
    train_text_data = list(train['New_Review'])
    dfmodel = pd.DataFrame(train_text_data, columns =['Train Review'] )
    dfmodel.to_csv('model_dependent.csv', index=False)
    test_text_data = list(test['Test_Review'])   
    corpus = train_text_data + test_text_data
    import pandas as pd
    datas = pd.DataFrame(corpus, columns=['Train Review'])
    datas.to_csv('model_dependent.csv',index=False)



    # for the vectorization
    tf = TfidfVectorizer()
    # the vectorizer must be fit onto the entire corpus
    fitted_vectorizer = tf.fit(corpus)

    # train
    train_transform = fitted_vectorizer.transform(train['New_Review'])
    ytrain = train['Polarity']
    # test
    test_transform = fitted_vectorizer.transform(test['Test_Review'])
    ytest = test['Polarity']

    return train_transform, ytrain, test_transform, ytest
    

def svm(train, test):
    print("\n========================================================================================\n")
    print("SVM")

    xtrain, ytrain, xtest, ytest = word_processing(train, test)
    # Import svm model
    from sklearn import svm

    # Create a svm Classifier
    clf = svm.SVC(kernel='linear')  # Linear Kernel

    # Train the model using the training sets
    clf.fit(xtrain, ytrain)
    print(f"Train result using SVM : {clf.score(xtrain, ytrain)}")

    pickle.dump(clf, open('svm.pkl', 'wb'))
    # Predict the response for test dataset
    predictions = clf.predict(xtest)

    # Import scikit-learn metrics module for accuracy calculation
    from sklearn import metrics

    # Model Accuracy: how often is the classifier correct?
    print("\nAccuracy of test using SVM :", metrics.accuracy_score(ytest, predictions))
    print("\nPrecission of test using SVM :", metrics.precision_score(ytest,predictions))
    print("\nRecall of test using SVM :", metrics.recall_score(ytest,predictions))
    print("\nF1-score of test using SVM :", metrics.f1_score(ytest,predictions))

     # result of confusion matrix
    print("\nConfusion Matrix :")
    cf_matrix= confusion_matrix(predictions, ytest)
    print(cf_matrix)
    print("\nConfusion Matrix % :")
    sum = cf_matrix.sum()
    cf_matrix = cf_matrix * 100.0 / ( 1.0 * sum )
    print(cf_matrix)
    import seaborn as sns
    sns.heatmap(cf_matrix, annot=True)
    
    # result of confusion matrix
    print("\nClassification Report :")
    print(classification_report(predictions, ytest))

   



def multiNB(train, test):
    print("\n========================================================================================\n")
    print("NAIVE BAYES")

    # data preprocessing
    xtrain, ytrain, xtest, ytest = word_processing(train, test)

    # train model using training dataset
    from sklearn.naive_bayes import MultinomialNB

    model = MultinomialNB()
    model.fit(xtrain, ytrain)
    print(f"Train result using Naive Bayes : {model.score(xtrain, ytrain)}")

    # save the model
    pickle.dump(model, open('NB.pkl', 'wb'))

    # Predict the response for test dataset
    predictions = model.predict(xtest)
    from sklearn import metrics
    print("\nAccuracy of test using Naive Bayes :", metrics.accuracy_score(ytest, predictions))
    print("\nPrecission of test using Naive Bayes :", metrics.precision_score(ytest,predictions))
    print("\nRecall of test using Naive Bayes :", metrics.recall_score(ytest,predictions))
    print("\nF1-score of test using Naive Bayes :", metrics.f1_score(ytest,predictions))
    
    # result of confusion matrix
    print("\nConfusion Matrix :")
    cf_matrix= confusion_matrix(predictions, ytest)
    print(cf_matrix)
    print("\nConfusion Matrix % :")
    sum = cf_matrix.sum()
    cf_matrix = cf_matrix * 100.0 / ( 1.0 * sum )
    print(cf_matrix)
    #import seaborn as sns
    #sns.heatmap(cf_matrix, annot=True)
    
    
    # result of classification report
    print("\nClassificaiton Report :")
    print(classification_report(predictions, ytest))

    




def logreg(train, test):
    print("\n========================================================================================\n")
    print("LOGISTIC REGRESSION")
    # data preprocessing
    xtrain, ytrain, xtest, ytest = word_processing(train, test)

    from sklearn.linear_model import LogisticRegression  # our model

    # train dataset using logistic regression using scikit-learn
    scikit_log_reg = LogisticRegression()

    model = scikit_log_reg.fit(xtrain, ytrain)
    print(f"Train result using Logistic Regression : {model.score(xtrain, ytrain)}")

    # save the model
    pickle.dump(model, open('logreg.pkl', 'wb'))

    # make prediction
    predictions = model.predict(xtest)

    # Import scikit-learn metrics module for accuracy calculation
    from sklearn import metrics
    print("\nAccuracy of test using Logistic Regression :", metrics.accuracy_score(ytest, predictions))
    print("\nPrecission of test using Logistic Regression :", metrics.precision_score(ytest,predictions))
    print("\nRecall of test using Logistic Regression :", metrics.recall_score(ytest,predictions))
    print("\nF1-score of test using Logistic Regression :", metrics.f1_score(ytest,predictions))

    # perfom logreg to calculate accuracy,prediction n recall
    from sklearn.metrics import confusion_matrix, classification_report

    # result of confusion matrix
    print("\nConfusion Matrix :")
    cf_matrix= confusion_matrix(predictions, ytest)
    print(cf_matrix)
    print("\nConfusion Matrix % :")
    sum = cf_matrix.sum()
    cf_matrix = cf_matrix * 100.0 / ( 1.0 * sum )
    print(cf_matrix)
    #import seaborn as sns
    #sns.heatmap(cf_matrix, annot=True)
    
    
    # result of classification Report
    print("\nClassification Report :")
    print(classification_report(predictions, ytest))

    

svm(train, test)
multiNB(train, test)
logreg(train, test)

